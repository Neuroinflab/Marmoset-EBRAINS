import numpy as np
import asyncio
#from databases import Database
import psycopg2

import pandas as pd

C_TRACERS = {
    "DY": "Diamidino Yellow",
    "FB": "Fast Blue",
    "CTBgr": "Cholera Toxin Subunit B Alexa 488",
    "CTBr": "Cholera Toxin Subunit B Alexa 594",
    "FR": "fluororuby (dextran-conjugated tetramethylrhodamine, molecular weight 10,000, 15%)",
    "FE": "fluoroemerald (dextran-conjugated fluorescein, molecular weight 10,000, 15%)"
}

###Whatever is / are our input datasets
###df = pd.read_excel("meta.xlsx")
###df.columns = ["case_id", "hemisphere", "sex", "weight", "age", "no_areas"]

async def main():
    results = []
    header = ["subject", "sex", "age_category", "species", "age", "weight",
              "strain", "pathology", "phenotype", "handedness", "laterality",
              "origin", "sampletype", "brain_area", "file_1", "file_2", "file_3",
              "technique_1", "technique_2", "technique_3", "tracer_code"]

    engine = psycopg2.connect('postgres://monash:marmosetConnectome@bqhzb5wces5.db.cloud.edu.au/marmoset')

    df = pd.read_sql("""
                     SELECT inj.memo, t.code tracer_code, s.code section_code, m.case_id, m.sex, m.dob,
                        m.injection_date, inj.hemisphere, m.body_weight weight, r.name as area,
                        inj.section_x_mm, inj.section_y_mm
                     FROM injection inj
                     JOIN marmoset m ON inj.marmoset_id = m.id
                     JOIN section s ON inj.section_id = s.id
                     JOIN tracer t ON t.id = inj.tracer_id
                     JOIN region r ON inj.region_id = r.id
                     ORDER BY m.id, inj.id
                     """, con=engine)
    print(df)
    for idx, row in df.iterrows():
        if row.sex == "M":
            _sex = "male"
        if row.sex == "F":
            _sex = "female"

        print(row.hemisphere)
        if row.hemisphere is not None:
            if row.hemisphere.strip() == "R":
                _laterality = "right"
            if row.hemisphere.strip() == "L":
                _laterality = "left"
        else:
            _laterality = 'unspecified'

        if row.injection_date and row.dob:
            years = row.injection_date.year - row.dob.year
            months = row.injection_date.month - row.dob.month
            if months < 0:
                years -= 1
                months += 12
            days = row.injection_date.day - row.dob.day
            if days < 0:
                months -= 1
            age = str(years) + ' ' + ('years' if years > 1 else 'year') if years > 0 else ''
            age += ' and ' if years > 0 and months > 0 else ''
            age += str(months) + ' ' + ('months' if months > 1 else 'month') if months > 0 else ''
        else:
            age = 'unspecified'
        url = 'http://www.marmosetbrain.org/goto/%s/%s/%s/%s/3' % (
            row.case_id, row.section_code, row.section_x_mm, row.section_y_mm
        )
        if not np.isnan(row.weight):
            weight = str(int(row.weight)) + 'g'
        else:
            weight = 'unspecified'
        results.append([str(row.case_id),         # subject
                        _sex,                    # sex
                        "Adult",                 # age_category
                        "Callithrix jacchus",    # species
                        age,             # age             # please compute the age as displayed on the website (in a user friendly way)
                        weight,    # weight
                        "none",                  # strain
                        "none",                  # pathology
                        "Wildtype",              # phenotype
                        "none",                  # handedness
                        _laterality,             # laterality
                        "brain",                 # origin
                        "tissue slice",          # sampletype
                        row.area,       # brain_area      # PLS use the full name of the area and then abbrev in parenthesis
                        url,                   # file_1  # pls use the url to the actual injection site as you generated recently.
                        "N/A",                   # file_2
                        "N/A",                   # file_3
                        "light microscopy",      # technique_1
                        "retrograde tracing",    # technique_2
                        C_TRACERS[row.tracer_code],        # technique_3     # PLS use the full name of the tracer according to the dict above
                        row.tracer_code,
                        ])
    vf=pd.DataFrame(results, columns=header)
    print(vf)

    vf.to_excel("marmoset_brain_connectivity_atlas_meta_for_ebrains.xlsx")
if __name__ == '__main__':
    asyncio.run(main())
